# Skyblock Hypixel client 

How to install Skyblock client 

1: Download it and open it with winrar 

2: Copy the folder and paste that folder in %appdata%  .Minecraft inside version's folder

3: Close all minecraft and go to the launcher and search in installations the hypixel client

4: Launch that and the u have it installed

Go to https://i.gyazo.com/8af933f6b9431fcbec7a18eaafb2741d.png to se all the spects

The client have included some awesome things too like : 

-> SKYBLOCK ADDONS 

-> ZEALOT COUNTER 

-> TALISMAN OPTIMIZER  

-> OPTIFINE 

-> BETTER FPS

-> MEMORY FIX 

-> VOID CHAT

